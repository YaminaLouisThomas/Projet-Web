function clique(){
	 alert("êtes vous sûr de vouloir recommencer?");
}

function ok(){
	alert("Ton cv est prêt, bienvenue dans notre communauté!");
}