var body = document.querySelector("body");
function mina(){
    body.style.background = "linear-gradient(grey,#E91E63)";
}