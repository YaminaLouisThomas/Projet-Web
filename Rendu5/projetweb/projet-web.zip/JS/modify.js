const buttonHome = document.querySelector('.home');
buttonHome.addEventListener('click', form_home);


countHome = 0
function form_home() {
    var form_home = document.querySelector(".form_home");
    var main =  document.querySelector("main");
    if (countHome == 0) {
        form_home.classList.add("display_form");
        main.classList.add("blurring");
        countHome += 1;
    }
    else {
        form_home.classList.remove("display_form");
        main.classList.remove("blurring");
        countHome -= 1;
    }
}